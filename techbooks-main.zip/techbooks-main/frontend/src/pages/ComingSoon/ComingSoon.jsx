import React from "react";
import styles from './ComingSoon.module.css'
const ComingSoon = () => {
  return <main className={styles.container}><div><h1 className={styles.text}>Coming soon !</h1></div></main>;
};

export default ComingSoon;
